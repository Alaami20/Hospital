/**
 * 
 */
/**
 * 
 */
module HW_3 {
	requires java.desktop;
}