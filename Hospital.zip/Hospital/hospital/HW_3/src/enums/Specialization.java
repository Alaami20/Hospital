package enums;

public enum Specialization {
	
	Neurology, 
	Other, 
	Cardiology, 
	Otolaryngology,
	Orthopedics, 
	Surgery, 
	Ophthalmology,
	Pulmonology, 
	IntensiveCare;

}
