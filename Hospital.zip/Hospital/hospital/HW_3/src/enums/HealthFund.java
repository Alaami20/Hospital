package enums;

public enum HealthFund {
	LeumitHealthCareServices,ClalitHealthServices,MaccabiHealthServices,KupatHolimMeuhedet;
}
