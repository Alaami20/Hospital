package model;

public interface IntensiveCareMedicalProblem {
	
	public void setIntensiveCare();

}
